﻿using Hospital.Data;
using Hospital.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Hospital.Controllers
{
    public class DoctorsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public DoctorsController(ApplicationDbContext context, IWebHostEnvironment webHostEnvironmen)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironmen;
        }


     

        
        [HttpGet]
        public IActionResult GetIndexView(string? search, string? sortType, string? sortOrder,
            int pageSize = 2, int pageNumber = 1)
        {
            IQueryable<Doctor> docs = _context.Doctors.AsQueryable();


            if (string.IsNullOrWhiteSpace(search) == false)
            {
                search = search.Trim();
                docs = _context.Doctors.Where(dc => dc.FullName.Contains(search));

            }


            if (!string.IsNullOrWhiteSpace(sortOrder) && !string.IsNullOrWhiteSpace(sortType))
            {
                if (sortType == "FullName")
                {
                    if (sortOrder == "asc")
                        docs = docs.OrderBy(dc => dc.FullName);
                    else if (sortOrder == "desc")
                        docs = docs.OrderByDescending(e => e.FullName);
                }

                else if (sortType == "Position")
                {
                    if (sortOrder == "asc")
                        docs = docs.OrderBy(dc => dc.Position);
                    else if (sortOrder == "desc")
                        docs = docs.OrderByDescending(dc => dc.Position);
                }

                else if (sortType == "Salary")
                {
                    if (sortOrder == "asc")
                        docs = docs.OrderBy(dc => dc.Salary);
                    else if (sortOrder == "desc")
                        docs = docs.OrderByDescending(dc => dc.Salary);
                }
            }
            ViewBag.PageSize = pageSize;
            ViewBag.PageNumber = pageNumber;
            docs = docs.Skip(pageSize * (pageNumber - 1)).Take(pageSize);
            return View("Index", docs);
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View(_context.Doctors);
        }



        [HttpGet]
        public IActionResult GetDetailsView(int id)
        {
            Doctor doc = _context.Doctors.Include(dc => dc.Department).FirstOrDefault(dc => dc.Id == id);
            if (doc == null)
            {
                return NotFound();
            }
            return View("Details", doc);
        }

        [HttpGet]
        public IActionResult Details(int id)
        {
            Doctor doc = _context.Doctors.Include(dc => dc.Department).FirstOrDefault(dc => dc.Id == id);
            if (doc == null)
            {
                return NotFound();
            }
            return View(doc);
        }

        [HttpGet]
        public IActionResult GetCreateView()
        {
            ViewBag.AllDepartments = _context.Departments.ToList();

            return View("Create");
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddDoctor([Bind("Id, FullName,Position,Salary,Bouns , PhoneNo , Email ," +
            "ConfirmEmail,Password ,ConfirmPassword," +
            "HiringDateTime,BirthDate,AttendanceTime,LeavingTime,CreatedAt,LastUpdateAt,DepartmentId")]
            Doctor doc, IFormFile? imageFile)
        {
            if (ModelState.IsValid == true)
            {
                if (imageFile == null)
                {
                    doc.ImageUrl = "\\images\\No_Image.png";
                }
                else
                {
                    string imgExtension = Path.GetExtension(imageFile.FileName);
                    Guid imgGuid = Guid.NewGuid();
                    string imgName = imgGuid + imgExtension;
                    string imgUrl = "\\images\\" + imgName;
                    doc.ImageUrl = imgUrl;

                    string imgPath = _webHostEnvironment.WebRootPath + imgUrl;

                    FileStream imgStream = new FileStream(imgPath, FileMode.Create);

                    imageFile.CopyTo(imgStream);
                    imgStream.Dispose();

                }



                doc.CreatedAt = DateTime.Now;
                _context.Doctors.Add(doc);
                _context.SaveChanges();

                return RedirectToAction("GetIndexView");
            }
            else
            {
                ViewBag.AllDepartments = _context.Departments.ToList();
                return View("Create");
            }

        }

        [HttpGet]
        public IActionResult GetEditView(int id)
        {
            Doctor doc = _context.Doctors.FirstOrDefault(dc => dc.Id == id);
            if (doc == null)
            {
                return NotFound();
            }
            ViewBag.AllDepartments = _context.Departments.ToList();
            return View("Edit", doc);
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditCurrent(int id, [Bind("Id, FullName,Position,Salary,Bouns , PhoneNo , Email ," +
            "ConfirmEmail,Password ,ConfirmPassword," +
            "HiringDateTime,BirthDate,AttendanceTime,LeavingTime,CreatedAt," +
            "LastUpdateAt,DepartmentId , ImageUrl")] Doctor doc, IFormFile? imageFile)
        {
            if (doc.Id != id)
            {
                return BadRequest();
            }

            if (ModelState.IsValid == true)
            {
                if (imageFile != null)
                {
                    if (doc.ImageUrl != "\\images\\No_Image.png")
                    {
                        string oldImgPath = _webHostEnvironment.WebRootPath + doc.ImageUrl;

                        if (System.IO.File.Exists(oldImgPath))
                        {
                            System.IO.File.Delete(oldImgPath);
                        }

                    }


                    string imgExtension = Path.GetExtension(imageFile.FileName);
                    Guid imgGuid = Guid.NewGuid();
                    string imgName = imgGuid + imgExtension;
                    string imgUrl = "\\images\\" + imgName;
                    doc.ImageUrl = imgUrl;

                    string imgPath = _webHostEnvironment.WebRootPath + imgUrl;

                    FileStream imgStream = new FileStream(imgPath, FileMode.Create);

                    imageFile.CopyTo(imgStream);
                    imgStream.Dispose();

                }

                doc.LastUpdateAt = DateTime.Now;
                _context.Doctors.Update(doc);
                _context.SaveChanges();

                return RedirectToAction("GetIndexView");
            }
            else
            {
                ViewBag.AllDepartments = _context.Departments.ToList();
                return View("Edit", doc);
            }

        }


        [HttpGet]
        public IActionResult GetDeleteView(int id)
        {
            Doctor doc = _context.Doctors.Include(dc => dc.Department).FirstOrDefault(dc => dc.Id == id);
            if (doc == null)
            {
                return NotFound();
            }
            return View("Delete", doc);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteCurrent(int id)
        {
            Doctor doc = _context.Doctors.FirstOrDefault(dc => dc.Id == id);

            if (doc.ImageUrl != "\\images\\No_Image.png")
            {
                string imgPath = _webHostEnvironment.WebRootPath + doc.ImageUrl;

                if (System.IO.File.Exists(imgPath))
                {
                    System.IO.File.Delete(imgPath);
                }

            }

            _context.Doctors.Remove(doc);
            _context.SaveChanges();

            return RedirectToAction("GetIndexView");
        }
    }
}
