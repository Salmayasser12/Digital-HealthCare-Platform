﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hospital.Models
{
    public class Doctor
    {
        public int Id { get; set; }

        [DisplayName("Full Name")]
        [Required(ErrorMessage = "You have to provide a vaild full name.")]
        [MinLength(12, ErrorMessage = "Full name mustn’t be less than 12 characters.")]
        public string FullName { get; set; }



        [Display(Name = "Medical specialty")]
        [Required(ErrorMessage = "You have to provide a vaild Medical specialty.")]
        [MinLength(2, ErrorMessage = "Medical specialty mustn’t be less than 5 characters.")]
        public string Position { get; set; }


        [Range(3000, 100000, ErrorMessage = "Salary must be between EGP 3000 and EGP 100000")]
        public double Salary { get; set; }



        [Range(1000, double.MaxValue, ErrorMessage = "Bouns  mustn’t be less than 1000")]
        public double Bouns { get; set; }



        [RegularExpression("^0\\d{10}$", ErrorMessage = "Invalid Phone Number")]
        public string PhoneNo { get; set; }



        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)
        |(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }



        [NotMapped]
        [Compare("Email", ErrorMessage = "Email and Confirmed email do not match.")]
        public string ConfirmEmail { get; set; }




        [DataType(DataType.Password)]
        public string Password { get; set; }



        [NotMapped]
        [Compare("Password", ErrorMessage = "Password and Confirmed Password do not match.")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }

        public DateTime HiringDateTime { get; set; }

        [DataType(DataType.Date)]
        public DateTime BirthDate { get; set; }

        [DataType(DataType.Time)]
        public DateTime AttendanceTime { get; set; }

        [DataType(DataType.Time)]
        public DateTime LeavingTime { get; set; }

        [ValidateNever]
        public DateTime CreatedAt { get; set; }
        [ValidateNever]
        public DateTime LastUpdateAt { get; set; }


        [DisplayName("Department")]
        [Range(1, int.MaxValue, ErrorMessage = "Choose Valid Department")]


        public int DepartmentId { get; set; }
       [ValidateNever]
        public Department Department { get; set; }



         [DisplayName("Image")]
         [ValidateNever]
          public string ImageUrl { get; set; }
    }
    }
