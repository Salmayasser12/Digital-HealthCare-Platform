﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace Hospital.Models
{
    public class Department
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "You have to provide a vaild Name.")]
        [MinLength(2, ErrorMessage = "Name mustn’t be less than 2 characters.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "You have to provide a vaild Medical specialty.")]
        [MinLength(1, ErrorMessage = "Position must be more than 1 characters.")]

        public string Description { get; set; }

        [ValidateNever]
        public ICollection<Doctor> Doctors { get; set; }
    }
}
